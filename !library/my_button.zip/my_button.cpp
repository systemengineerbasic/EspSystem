/*******************************************************************
    my_button.cpp
       
    Button control library

*******************************************************************/


#define	PIN_BUTTON	(0)


//=====================================
// Initialize button
//=====================================
void init_button()
{
    pinMode(PIN_BUTTON, INPUT);
}

//=====================================
// Get button status(On or Off)
//=====================================
int get_button_status()
{
	int button_status = digitalRead(PIN_BUTTON);
    if(button_status == 0) { // If button is pushed
        return  1;
    }
    else {
        return  0;
    }
}

